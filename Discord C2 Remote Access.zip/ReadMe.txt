Welcome to the last update of the discord C2 Remote Access Control !

This is a very light and simple way to gain access to any distant computer.

Step 1 : Run the "Discord C2 Remote Access.exe" on your computer.

Step 2 : Drop the payload.txt into your flipper zero (or any other BADUSB key)

Step 3 : Run the payload.txt on the targeted machine you want to remote access.

Now, the Discord C2 Remote Access app will ask you if you wanna start the remote session with the victim, and now enjoy !